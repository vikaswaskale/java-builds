package com.delloite.assesment.todolist.repos;

import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.delloite.assesment.todolist.model.ToDo;

@CrossOrigin(origins="http://localhost:4200")
public interface ToDoRepository extends CrudRepository<ToDo, String> {
}